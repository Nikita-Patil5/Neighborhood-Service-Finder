package com.neighborhood.servicefinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeighborhoodServiceFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeighborhoodServiceFinderApplication.class, args);
	}

}
